import React from "react";
import Users from "./components/PropTypes/Users";

export default function App() {
  return (
    <div>
      <Users />
    </div>
  );
}
