import React from 'react'

export default function HomePage() {
    return (
        <div>
            <h1>Welcome to HomePage</h1>
        </div>
    )
}
