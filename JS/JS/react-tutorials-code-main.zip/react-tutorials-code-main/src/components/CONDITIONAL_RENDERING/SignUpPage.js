import React from 'react'

export default function SignUpPage() {
    return (
        <div>
            <h1>Please Sign up</h1>
        </div>
    )
}
