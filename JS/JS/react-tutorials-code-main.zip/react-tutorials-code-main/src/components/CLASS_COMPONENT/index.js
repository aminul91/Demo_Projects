import React, { Component } from 'react'

class CLASS_COMPONENT extends Component {
    render() {
        return (
            <div>
                <h1>Example of a class component</h1>
            </div>
        )
    }
}

export default CLASS_COMPONENT
