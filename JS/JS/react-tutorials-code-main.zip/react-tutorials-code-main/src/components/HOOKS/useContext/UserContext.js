import React from "react";
export const UserContext = React.createContext();

// setp1 : create context
// step2: wrap childs with context provider
// setp3: state access useContext hook
