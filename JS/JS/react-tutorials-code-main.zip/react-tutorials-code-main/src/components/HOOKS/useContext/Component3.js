import React from "react";
import Component4 from "./Component4";

const Component3 = () => {
  return (
    <div>
      <Component4 />
    </div>
  );
};

export default Component3;
