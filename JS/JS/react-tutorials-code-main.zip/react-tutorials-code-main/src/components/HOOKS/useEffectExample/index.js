// import React, { useState, useEffect } from "react";

export default function USE_EFFECT() {
  // const [searchData, setSearchData] = useState("");
  // const [data, setData] = useState([]);

  // useEffect(() => {
  //   fetch("https://jsonplaceholder.typicode.com/posts")
  //     .then((response) => response.json())
  //     //   .then((json) => console.log(json));
  //     .then((json) => {
  //       setData(json);
  //       // console.log(data);
  //     });
  // }, [data]);

  // useEffect(() => {
  //   console.log(searchData);
  // }, [searchData]);

  // const handleChange = (e) => {
  //   setSearchData(e.target.value);
  // };

  return (
    <div>
      {/* <form action="">
        <h1>{searchData}</h1>
        <input
          type="text"
          name="searchData"
          value={searchData}
          onChange={handleChange}
        />
      </form>
      <ul>
        {data.map((item, index) => (
          <li key={index}>{item.title}</li>
        ))}
      </ul> */}
      hi
    </div>
  );
}
