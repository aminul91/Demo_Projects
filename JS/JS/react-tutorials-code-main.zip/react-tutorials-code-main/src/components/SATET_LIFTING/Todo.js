import React from "react";

const Todo = (props) => {
  return <p>{props.todo}</p>;
};

export default Todo;
