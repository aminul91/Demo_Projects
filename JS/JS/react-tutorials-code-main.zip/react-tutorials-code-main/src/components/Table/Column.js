import React from "react";

const Column = () => {
  return (
    <>
      <td>Anisul Islam</td>
      <td>32 years old</td>
    </>
  );
};

export default Column;
