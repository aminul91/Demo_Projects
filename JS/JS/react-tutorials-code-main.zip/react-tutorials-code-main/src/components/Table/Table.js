import React from "react";
import Column from "./Column";

const Table = () => {
  return (
    <table>
      <tr>
        <Column />
      </tr>
      <tr>
        <Column />
      </tr>
    </table>
  );
};

export default Table;
